package com.PubSubDemo.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.messaging.MessageChannel;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.cloud.spring.pubsub.core.PubSubTemplate;
import com.google.cloud.spring.pubsub.integration.AckMode;
import com.google.cloud.spring.pubsub.integration.inbound.PubSubMessageSource;
import com.google.cloud.spring.pubsub.support.converter.JacksonPubSubMessageConverter;
import com.google.pubsub.v1.ProjectSubscriptionName;

@Configuration
public class BeanConfiguration {
	
	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper().registerModule(new JavaTimeModule())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
				.setDefaultPropertyInclusion(Include.NON_NULL);
	}
	

	@Bean
	public JacksonPubSubMessageConverter jacksonPubSubMessageConverter(ObjectMapper ojectMapper) {
		return new JacksonPubSubMessageConverter(ojectMapper);
	}
	

	@Bean
	public MessageChannel statusChannel() {
		return new DirectChannel();
	}
	
	@Bean
	public org.springframework.integration.core.MessageSource<Object> statusMessageChannelAdopter(PubSubTemplate simplePubSubTemplate){
		final String subName = ProjectSubscriptionName.format("valid-might-365117", "PubSubStringOnly-sub");
		PubSubMessageSource mesageSource = new PubSubMessageSource(simplePubSubTemplate, subName);
		mesageSource.setAckMode(AckMode.MANUAL);
		mesageSource.setBlockOnPull(true);
		mesageSource.setMaxFetchSize(100);
		return mesageSource;
		
	}
	
	
	
	/*	@Bean
	public JacksonPubSubMessageConverter jacksonPubSubMessageConverter() {
		return new JacksonPubSubMessageConverter(new ObjectMapper());
	}
	*/
	
	/*	@Bean
	public PubSubTemplate simplePubSubTemplate(PubSubPublisherTemplate pubSubPublisherTemplate,
			PubSubSubscriberTemplate pubSubSubscriberTemplate) {
		PubSubTemplate simplePubSubTemplate = new PubSubTemplate(pubSubPublisherTemplate, pubSubSubscriberTemplate);
		simplePubSubTemplate.setMessageConverter(new SimplePubSubMessageConverter());
		return simplePubSubTemplate;
	}

	@Bean
	public PubSubTemplate jacksonPubSubTemplate(PubSubPublisherTemplate pubSubPublisherTemplate,
			PubSubSubscriberTemplate pubSubSubscriberTemplate,
			JacksonPubSubMessageConverter jacksonPubSubMessageConverter) {
		PubSubTemplate jacksonPubSubTemplate = new PubSubTemplate(pubSubPublisherTemplate, pubSubSubscriberTemplate);
		jacksonPubSubTemplate.setMessageConverter(jacksonPubSubMessageConverter);
		return jacksonPubSubTemplate;
	}
	*/

}
