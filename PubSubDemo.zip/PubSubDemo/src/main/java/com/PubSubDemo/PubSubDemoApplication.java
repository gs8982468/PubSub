package com.PubSubDemo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.spring.pubsub.core.PubSubOperations;
import com.google.cloud.spring.pubsub.integration.AckMode;
import com.google.cloud.spring.pubsub.integration.inbound.PubSubInboundChannelAdapter;
import com.google.cloud.spring.pubsub.support.GcpPubSubHeaders;

@SpringBootApplication
public class PubSubDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PubSubDemoApplication.class, args);
	}
	
	// Create MessageChannel Bean for pubsubInputChannel
		/*@Bean
		public MessageChannel pubsubInputChannel() {
			return new DirectChannel();
		}*/

		// Create PubSubInboundChannelAdapter Bean for messageChannelAdapter
		/*@Bean
		public PubSubInboundChannelAdapter messageChannelAdapter(
				@Qualifier("pubsubInputChannel") MessageChannel inputChannel, PubSubOperations pubSubTemplate) {
			PubSubInboundChannelAdapter adapter = new PubSubInboundChannelAdapter(pubSubTemplate, "testSubscription");
			adapter.setOutputChannel(inputChannel);
			adapter.setAckMode(AckMode.MANUAL);
			return adapter;
		}*/

		// Create Service Activator Bean for Pub sub input channel
/*		@Bean
		@ServiceActivator(inputChannel = "pubsubInputChannel")
		public MessageHandler messageReceiver() {
			return message -> {
				System.out.println("Message Received::" + message.getPayload());
				AckReplyConsumer consumer = (AckReplyConsumer) message.getHeaders().get(GcpPubSubHeaders.ACKNOWLEDGEMENT);
				consumer.ack();
			};
		}
*/
}
