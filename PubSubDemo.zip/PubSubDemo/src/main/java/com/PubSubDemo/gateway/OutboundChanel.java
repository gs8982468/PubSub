package com.PubSubDemo.gateway;

import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;

import com.PubSubDemo.Configuration.Emloyee;

@MessagingGateway(name="myPubSubGateway", defaultRequestChannel = "outboundMsgChanel")
public interface OutboundChanel {	
	void sendMsgToPubSub(String msg);
	
	void sendMsgToPubSub(Emloyee msg);
	
	void sendMsgToPubSubTemp(@Payload Emloyee msg, @Header("Subhankar Project : ") String projectId, @Header("GGG2")  String topic);
}
