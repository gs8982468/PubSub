package com.PubSubDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.EmptyReaderEventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.PubSubDemo.Configuration.Emloyee;
import com.PubSubDemo.gateway.OutboundChanel;

@Component
@RestController
public class PublishController {
	
	@Autowired
	OutboundChanel gateway;
	
	@PostMapping("/publishMessage")
	public String publishMessage(@RequestBody String msg) {
		gateway.sendMsgToPubSub(msg);
		return "Message sent to PubSub successfully";
	}
	
	@PostMapping("/publish/Message")
	public String publishMessages(@RequestBody Emloyee msg) {
		gateway.sendMsgToPubSub(msg);
		return "Employee Json sent to PubSub successfully";
	}
	
	@PostMapping("/publish/Message/1")
	public String publishMessagess(@RequestBody Emloyee msg) {
		gateway.sendMsgToPubSubTemp(msg, "valid-might-365117","PbSubDemo");
		return "Employee Json sent to PubSub successfully";
	}


}
