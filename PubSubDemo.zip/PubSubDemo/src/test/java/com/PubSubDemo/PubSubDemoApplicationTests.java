package com.PubSubDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PubSubDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
